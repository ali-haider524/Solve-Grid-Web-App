import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SolveGrid | Free Online Math & Engineering Tools",
  description:
    "SolveGrid provides free online graphing, scientific, equation, matrix, and engineering calculation tools.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}